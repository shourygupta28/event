{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"https://skywarriorthemes.com/benri/demo1/#organization","name":"","url":"https://skywarriorthemes.com/benri/demo1/","sameAs":[]},{"@type":"WebSite","@id":"https://skywarriorthemes.com/benri/demo1/#website","url":"https://skywarriorthemes.com/benri/demo1/","name":"Agency - Demo 1","publisher":{"@id":"https://skywarriorthemes.com/benri/demo1/#organization"},"potentialAction":{"@type":"SearchAction","target":"https://skywarriorthemes.com/benri/demo1/?s={search_term_string}","query-input":"required name=search_term_string"}},{"@type":"WebPage","@id":"https://skywarriorthemes.com/benri/demo1/portfolio/1420-3/#webpage","url":"https://skywarriorthemes.com/benri/demo1/portfolio/1420-3/","inLanguage":"en-US","name":"Hero video background - Agency - Demo 1","isPartOf":{"@id":"https://skywarriorthemes.com/benri/demo1/#website"},"image":{"@type":"ImageObject","@id":"https://skywarriorthemes.com/benri/demo1/portfolio/1420-3/#primaryimage","url":"https://skywarriorthemes.com/benri/demo1/wp-content/uploads/sites/17/2017/05/bench-accounting-49025.jpg","width":2000,"height":1338},"primaryImageOfPage":{"@id":"https://skywarriorthemes.com/benri/demo1/portfolio/1420-3/#primaryimage"},"datePublished":"2017-05-17T20:04:52+00:00","dateModified":"2018-04-10T17:52:37+00:00"}]}
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/skywarriorthemes.com\/benri\/demo1\/wp-includes\/js\/wp-emoji-release.min.js"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
/* <![CDATA[ */
var LS_Meta = {"v":"6.7.1"};
/* ]]> */
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/benri\/demo1\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/benri\/demo1\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/skywarriorthemes.com\/benri\/demo1","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/skywarriorthemes.com\/benri\/demo1\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};
/* ]]> */
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/benri\/demo1\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/benri\/demo1\/?wc-ajax=%%endpoint%%"};
/* ]]> */
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/benri\/demo1\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/benri\/demo1\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_0b5f361231a0a52f1f4003c157e31f3d","fragment_name":"wc_fragments_0b5f361231a0a52f1f4003c157e31f3d","request_timeout":"5000"};
/* ]]> */
/* <![CDATA[ */
var settingsGlobal = {"fixedMenu":"fixed","leftMenu":"0","menuLayout":"right-aligned-menu","onePage":"0","ajaxurl":"https:\/\/skywarriorthemes.com\/benri\/demo1\/wp-admin\/admin-ajax.php","searchFor":"Search for...","blog_feed":"standard_full"};
/* ]]> */

